function emgWeightedAverage = EWA(time,emg,mech)
%
% -------------------------------------------------------------------------
%
% EWA.m
%
% call: emgWeightedAverage = EWA(time,emg,mech);
%
% EWA.m computes the EMG-weighted average (EWA) on a set of mechanical
% output (i.e. endpoint force or joint torque) based on the EMG signal from
% a muscle. The EMG signal need not be processed, and can be acquired by a
% surface electrode or non-selective intramuscular electrode.
%
% Inputs:
%
% - time : a t by 1 vector where t is the number of time points in the
% trial. time specfies the time that each sample was recorded
% - emg: a t by 1 vector specifying the recorded EMG signal at each time
% point
% - mech : a t by n matrix where n is the number of mechanical outputs.
% Each row of mech specifies the value of all mechanical outputs for each
% time point. Different mechanical outputs could be the joint torque at the
% shoulder, elbow, and wrist, or the x, y, and z components of force at the
% hand.
%
% Outputs:
% - emgWeightedAverage (a struct)
%   .time (a vector of time shifts, in seconds, over which the EWA was
%   computed)
%   .value (a matrix. The ith column is the EWA for the ith mechanical
%   output)
%
% Example:
% Type >> load EwaExample.mat
% This data was sampled at 2000 Hz. The EMG signal is a surface EMG signal
% from the human first dorsal interosseous (FDI). The first column of
% mechanical output is index finger abduction force in Newtons, and the
% second column of mechanical output is the index finger flexion force in
% Newtons. Then, type
%
% >> emgWeightedAverage = EWA(time,emg,mech);
% 
% Use the cross-hairs that appear to have the vertical line mark the
% beginning of hold phase of the trial (it doesn't matter which set of axes 
% you click on), and then mark the end of the hold phase, following the
% instructions in the title of the trial. To see the EWA, type
%
% >> figure, hold on
% >> plot(emgWeightedAverage.time,emgWeightedAverage.value(:,1));
% >> plot(emgWeightedAverage.time,emgWeightedAverage.value(:,2),'r');
%
% The blue curve will be the EWA of the abduction force based on the FDI
% EMG, and the red curve will be the EWA of the flexion force based on the
% FDI EMG. 
%
% (c) Jason J. Kutch, 2011
% kutch@usc.edu
%
% If you use EWA in a publication, please cite:
% 
% Kutch JJ, Kuo AD, Rymer WZ (2010) Extraction of individual muscle 
% mechanical action from endpoint force. J Neurophysiol 103:3535-3546.
% 
% -------------------------------------------------------------------------


% determine basic array sizes
t = length(time);                                                          
n = size(mech,2);                                                           
sampFreq = 1/mean(diff(time));
snippetStartInd = round(0.05*sampFreq);
snippetEndInd = round(0.1*sampFreq);
numEwaPts = snippetStartInd+snippetEndInd+1;                                

% make sure EMG is rectified, and normalize it to have unit area
emg = abs(emg);
iEmg = trapz(time,emg);
emg = emg/iEmg;

% plot raw time signals of EMG and mechanical output
h = figure;
for i = 1:n
 subplot(n+1,1,i),plot(time,mech(:,i)),ylabel(['Mech output ' num2str(i)]);
end
subplot(n+1,1,n+1),plot(time,emg),ylabel(['EMG signal']),xlabel('time');

% prompt user to mark the beginning and end of hold phase
set(h,'name','Mark the time at which steady output began');
steadyStartTime = ginput(1);
set(h,'name','Mark the time at which steady output ended');
steadyEndTime = ginput(1);

% determine array indices of hold phase
steadyStartInd = min(find(time>steadyStartTime(1)));
steadyEndInd = max(find(time<steadyEndTime(1)));

% perform EMG-weighted averaging
emgWeightedAverage.time = [-snippetStartInd:snippetEndInd]'/sampFreq;
emgWeightedAverage.value = zeros(numEwaPts,n);

for i = 1:n
    for j = steadyStartInd+numEwaPts:steadyEndInd-numEwaPts
        mechSnippet = mech(j-snippetStartInd:j+snippetEndInd,i);
        mechSnippet = mechSnippet-mechSnippet(snippetStartInd+1);
        emgWeightedAverage.value(:,i) = emgWeightedAverage.value(:,i) + emg(j)*mechSnippet;
    end
end